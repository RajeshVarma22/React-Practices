import React from 'react'
// import './EmptyData.css'

const EmptyData = () => {
  return (
    <div id='EmptyData' className='d-flex flex-column justify-content-center align-items-center mh-100'>
      <h1>This data is Empty.</h1>
    </div>
  )
}

export default EmptyData