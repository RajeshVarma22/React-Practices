import React, { useState } from "react";
import "./kk.css";
const AssetTemplates = () => {
  const [assetType, setAssetType] = useState("");

  return (
    <div id="AssetTemplates">
      <div id="assetTemplateBox">
        <div id="templteHead">
          <h5>NEW ASSET TEMPLATE</h5>
        </div>
        <form>
          <div>
            <label htmlFor="assetType">ASSET TYPE</label>
            <input
              className="inputBox"
              id="assetType"
              placeholder="Enter the name off the asset type"
              value={assetType}
              onChange={(e) => setAssetType(e.target.value)}
            ></input>
          </div>
          <div>
            <label htmlFor="assetType">MEASUREMENT 1</label>
            <input
              className="inputBox"
              id="assetType"
              placeholder="Enter measurement name"
              value={assetType}
              onChange={(e) => setAssetType(e.target.value)}
            ></input>
          </div>
        </form>
      </div>
      <div id="buttons">
        <button className="btnBlack">SAVE</button>
        <button className="btnBlack">RESET</button>
      </div>
    </div>
  );
};

export default AssetTemplates;
