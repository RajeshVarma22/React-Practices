import React, { useState } from "react";
import Single from "./Single";
import { Link } from "react-router-dom";

const PresentTemplates = ({seDataNum}) => {
  const [data, setData] = useState([
    { textOne: "gfdggf", textTwo: 4656 },
    { textOne: "sasa", textTwo: 46656556 },
    { textOne: "haha", textTwo: 46656556 },
  ]);
  const [text1, setText1] = useState("");
  const [text2, setText2] = useState("");

  const submitForm = () => {
    let obj = {
      textOne: text1,
      textTwo: text2,
    };

    setData([...data, obj]);
  };

  const sendDataApp = (item) => {
    let cahngeObj = JSON.stringify(item)
    seDataNum(cahngeObj)
  }

  return (
    <div id="PresentTemplates">
      {data.length > 0 ? (
        data.map((item, index) => {
          return (
            <div>
              <Link to={"/single"} onClick={() => sendDataApp(item)} key={index}>{item.textOne}</Link>
            </div>
          );
        })
      ) : (
        <form className="ms-4" onSubmit={submitForm}>
          <input
            type="text"
            placeholder="text1"
            value={text1}
            onChange={(e) => setText1(e.target.value)}
          />
          <br />
          <input
            type="text"
            placeholder="text2"
            value={text2}
            onChange={(e) => setText2(e.target.value)}
          />
          <br />
          <input type="submit" value="Submit" />
        </form>
      )}
    </div>
  );
};

export default PresentTemplates;
